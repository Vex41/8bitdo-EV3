#!/usr/bin/env pybricks-micropython
from pybricks.ev3devices import (Motor, TouchSensor, ColorSensor,
                                 InfraredSensor, UltrasonicSensor, GyroSensor)
from pybricks.parameters import (Port, Stop, Direction, Button, Color,
                                 SoundFile, ImageFile, Align)
from pybricks.tools import print, wait, StopWatch
import struct
 
left_motor = Motor(Port.B)
steer_motor = Motor(Port.A)
forward = 0
left = 0

def scale(val, src, dst):

    return (float(val-src[0]) / (src[1]-src[0])) * (dst[1]-dst[0])+dst[0]

infile_path = "/dev/input/event2"

in_file = open(infile_path, "rb")

FORMAT = 'llHHI'    
EVENT_SIZE = struct.calcsize(FORMAT)
event = in_file.read(EVENT_SIZE)

while event:
    (tv_sec, tv_usec, ev_type, code, value) = struct.unpack(FORMAT, event)

    if ev_type == 3:
        if code == 2: 
            left = scale(value, (0,255), (2000, -2000))
        if code == 1:
            forward = scale(value, (0,255), (200,-200))
        
    left_motor.dc(forward)
    steer_motor.track_target(left)

    event = in_file.read(EVENT_SIZE)

in_file.close()